using System.Windows;
using System.Windows.Controls;

namespace SupressIt.Views.Panels
{
    public partial class NetworkPanel : UserControl
    {
        public event System.Action<string> BlockRequested;
        public NetworkPanel() => InitializeComponent();
        private void Block_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button { Tag: string name }) BlockRequested?.Invoke(name);
        }
    }
}
