using System.Windows;
using System.Windows.Controls;

namespace SupressIt.Views.Panels
{
    public partial class ServicesPanel : UserControl
    {
        public event System.Action<string> ToggleRequested;
        public event System.Action<string> BlockRequested;

        public ServicesPanel() => InitializeComponent();

        private void Toggle_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button { Tag: string name }) ToggleRequested?.Invoke(name);
        }

        private void Block_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button { Tag: string name }) BlockRequested?.Invoke(name);
        }
    }
}
