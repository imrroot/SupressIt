using System.Windows;
using System.Windows.Controls;
using SupressIt.Helpers;

namespace SupressIt.Views.Panels
{
    public partial class ProcessesPanel : UserControl
    {
        // (pid, blacklist, screenPoint, borderElement for death anim)
        public event System.Action<int, bool, Point, FrameworkElement> KillRequested;

        // Settings values injected by MainWindow
        public string DeathAnimationType { get; set; } = "Burn";
        public double DeathAnimationDuration { get; set; } = 0.6;

        public ProcessesPanel() => InitializeComponent();

        private void Kill_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;
            if (btn.Tag is not int pid) return;

            var card  = FindCard(btn);
            var pt    = btn.PointToScreen(new Point(18, 18));

            if (card != null && DeathAnimationType != "None")
            {
                // Play death animation first, THEN fire KillRequested when done
                DeathAnimator.Play(card, DeathAnimationType, DeathAnimationDuration,
                    () => KillRequested?.Invoke(pid, false, pt, card));
            }
            else
            {
                KillRequested?.Invoke(pid, false, pt, null);
            }
        }

        private void Block_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;
            if (btn.Tag is not int pid) return;

            var card = FindCard(btn);
            var pt   = btn.PointToScreen(new Point(18, 18));

            if (card != null && DeathAnimationType != "None")
            {
                DeathAnimator.Play(card, DeathAnimationType, DeathAnimationDuration,
                    () => KillRequested?.Invoke(pid, true, pt, card));
            }
            else
            {
                KillRequested?.Invoke(pid, true, pt, null);
            }
        }

        // Walk up visual tree to find the CardStyle Border
        private static FrameworkElement FindCard(DependencyObject child)
        {
            var current = child;
            while (current != null)
            {
                if (current is Border b && b.CornerRadius.TopLeft >= 14)
                    return b;
                current = System.Windows.Media.VisualTreeHelper.GetParent(current);
            }
            return null;
        }
    }
}
