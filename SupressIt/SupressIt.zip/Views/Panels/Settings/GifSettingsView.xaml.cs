using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using SupressIt.ViewModels;

namespace SupressIt.Views.Panels.Settings
{
    public partial class GifSettingsView : UserControl
    {
        public GifSettingsView() => InitializeComponent();
        private SettingsViewModel VM => DataContext as SettingsViewModel;

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button { Tag: string slot }) return;
            var dlg = new OpenFileDialog
            {
                Title  = $"Pick GIF for '{slot}' state",
                Filter = "GIF / Video|*.gif;*.webm;*.mp4|All files|*.*"
            };
            if (dlg.ShowDialog() != true || VM == null) return;
            switch (slot)
            {
                case "normal":    VM.GifNormalPath    = dlg.FileName; break;
                case "searching": VM.GifSearchingPath = dlg.FileName; break;
                case "kill":      VM.GifKillPath      = dlg.FileName; break;
                case "block":     VM.GifBlockPath     = dlg.FileName; break;
            }
        }
    }
}
