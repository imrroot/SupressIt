using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using SupressIt.ViewModels;

namespace SupressIt.Views.Panels.Settings
{
    public partial class SoundSettingsView : UserControl
    {
        public SoundSettingsView() => InitializeComponent();
        private SettingsViewModel VM => DataContext as SettingsViewModel;

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button { Tag: string slot }) return;
            var dlg = new OpenFileDialog
            {
                Title  = $"Pick sound for '{slot}'",
                Filter = "Audio|*.mp3;*.wav;*.ogg;*.m4a;*.aac;*.flac|All|*.*"
            };
            if (dlg.ShowDialog() != true || VM == null) return;
            switch (slot)
            {
                case "normal":    VM.SoundNormalPath    = dlg.FileName; break;
                case "searching": VM.SoundSearchingPath = dlg.FileName; break;
                case "kill":      VM.SoundKillPath      = dlg.FileName; break;
                case "block":     VM.SoundBlockPath     = dlg.FileName; break;
            }
        }
    }
}
