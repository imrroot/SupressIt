using System; using System.Collections.Generic; using System.Collections.ObjectModel;
using System.ComponentModel; using System.Linq; using System.Threading.Tasks;
using System.Windows; using System.Windows.Threading;
using SupressIt.Helpers; using SupressIt.Models; using SupressIt.Services;

namespace SupressIt.ViewModels
{
    public enum ActiveTab  { Processes,Services,Network,Startup,Blacklist,Settings }
    public enum AnimeState { Normal,Searching,Killing,Blocking }

    public class MainViewModel : INotifyPropertyChanged
    {
        readonly ProcessService   _proc  = new();
        readonly ServiceManager   _svc   = new();
        readonly NetworkMonitor   _net   = new();
        readonly VpnDetector      _vpn   = new();
        readonly StartupService   _start = new();
        readonly BlacklistService _bl    = new();
        readonly BlacklistWatcher _watch;
        readonly DispatcherTimer  _mainT, _vpnT, _searchT;

        Dictionary<int,long> _dn=new(), _up=new();

        public ObservableCollection<ProcessEntry>   Processes { get; } = new();
        public ObservableCollection<ServiceEntry>   Services  { get; } = new();
        public ObservableCollection<NetworkEntry>   Network   { get; } = new();
        public ObservableCollection<StartupEntry>   Startup   { get; } = new();
        public ObservableCollection<BlacklistEntry> Blacklist { get; } = new();
        public ObservableCollection<KillLogEntry>   KillLog   { get; } = new();

        ActiveTab _tab=ActiveTab.Processes;
        public ActiveTab ActiveTab{get=>_tab;set{_tab=value;P();Refresh();}}

        string _pending="", _search="";
        public string SearchText{get=>_pending;set{_pending=value;P();AnimeState=value.Length>0?AnimeState.Searching:AnimeState.Normal;_searchT.Stop();_searchT.Start();}}

        string _status="0 items";
        public string StatusText{get=>_status;private set{_status=value;P();}}

        string _td="0 B/s",_tu="0 B/s";
        public string TotalDown{get=>_td;private set{_td=value;P();}}
        public string TotalUp  {get=>_tu;private set{_tu=value;P();}}

        bool _va; string _vl="SCANNING...";
        public bool   VpnActive{get=>_va;private set{_va=value;P();}}
        public string VpnLabel {get=>_vl;private set{_vl=value;P();}}

        int _kc;
        public int KillCount{get=>_kc;private set{_kc=value;P();}}

        AnimeState _as=AnimeState.Normal;
        public AnimeState AnimeState{get=>_as;set{_as=value;P();AnimeStateChanged?.Invoke(value);}}

        bool _netLimEn; double _netLimMb=100;
        public bool   GlobalNetLimitEnabled{get=>_netLimEn;set{_netLimEn=value;P();}}
        public double GlobalNetLimitMb     {get=>_netLimMb;set{_netLimMb=value;P();}}

        public event Action               KillLogUpdated;
        public event Action<AnimeState>   AnimeStateChanged;
        public event Action<Point>        KillAnimationRequested;
        public event PropertyChangedEventHandler PropertyChanged;
        void P([System.Runtime.CompilerServices.CallerMemberName]string n="")=>PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(n));

        public MainViewModel()
        {
            _watch=new BlacklistWatcher(_bl);
            _watch.EnforcementAction+=(t,n,r)=>Application.Current?.Dispatcher.Invoke(()=>Log(t,"auto",n,r));
            _watch.Start();

            _searchT=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(350)};
            _searchT.Tick+=(_,__)=>{_searchT.Stop();_search=_pending;Refresh();if(string.IsNullOrEmpty(_search))AnimeState=AnimeState.Normal;};

            _mainT=new DispatcherTimer{Interval=TimeSpan.FromSeconds(2)};
            _mainT.Tick+=(_,__)=>Tick();

            _vpnT=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(2000)};
            _vpnT.Tick+=(_,__)=>CheckVpn();
            _vpnT.Start();

            _mainT.Stop();
            Task.Run(()=>{var empty=new Dictionary<int,long>();var procs=_proc.GetProcesses("",empty,empty);
                Application.Current.Dispatcher.Invoke(()=>{foreach(var p in procs)Processes.Add(p);StatusText=$"{Processes.Count} processes";Tick();CheckVpn();_mainT.Start();});});
        }

        public void Shutdown(){_mainT.Stop();_vpnT.Stop();_searchT.Stop();_watch.Stop();}

        void Tick(){(_dn,_up)=_net.Tick();var(td,tu)=_net.GetTotals(_dn,_up);TotalDown=Fmt(td);TotalUp=Fmt(tu);CheckNetLimits();Refresh();}

        public void Refresh(){switch(_tab){
            case ActiveTab.Processes:RefreshProcs();break;case ActiveTab.Services:RefreshSvcs();break;
            case ActiveTab.Network:RefreshNet();break;case ActiveTab.Startup:RefreshStart();break;
            case ActiveTab.Blacklist:RefreshBl();break;}}

        void RefreshProcs(){
            var fr=_proc.GetProcesses(_search,_dn,_up);var nm=fr.ToDictionary(e=>e.Pid);
            for(int i=Processes.Count-1;i>=0;i--)if(!nm.ContainsKey(Processes[i].Pid))Processes.RemoveAt(i);
            var seen=new HashSet<int>();var dup=new List<int>();
            for(int i=0;i<Processes.Count;i++)if(!seen.Add(Processes[i].Pid))dup.Add(i);
            for(int i=dup.Count-1;i>=0;i--)Processes.RemoveAt(dup[i]);
            var ex=Processes.ToDictionary(e=>e.Pid);
            foreach(var e in fr){if(ex.TryGetValue(e.Pid,out var x)){x.CpuPercent=e.CpuPercent;x.MemoryMb=e.MemoryMb;x.DownloadSpeed=e.DownloadSpeed;x.UploadSpeed=e.UploadSpeed;}else Processes.Add(e);}
            StatusText=$"{Processes.Count} processes";
        }

        void RefreshSvcs(){var fr=_svc.GetServices(_search);Services.Clear();foreach(var e in fr)Services.Add(e);StatusText=$"{Services.Count} services";}

        void RefreshNet(){
            var fr=_net.BuildEntries(_search,_dn,_up);
            var lm=Network.ToDictionary(e=>e.Pid,e=>(e.LimitEnabled,e.LimitBytes));
            Network.Clear();
            foreach(var e in fr){if(lm.TryGetValue(e.Pid,out var l)){e.LimitEnabled=l.LimitEnabled;e.LimitBytes=l.LimitBytes;}Network.Add(e);}
            StatusText=$"{Network.Count} connections";
        }

        void RefreshStart(){var fr=_start.GetStartupEntries(_search);Startup.Clear();foreach(var e in fr)Startup.Add(e);StatusText=$"{Startup.Count} startup items";}
        void RefreshBl(){var fr=_bl.GetAll();var low=_search?.ToLower()??"";if(!string.IsNullOrEmpty(low))fr=fr.Where(e=>e.Name.ToLower().Contains(low)).ToList();Blacklist.Clear();foreach(var e in fr)Blacklist.Add(e);StatusText=$"{Blacklist.Count} blacklisted";}

        void CheckNetLimits(){
            foreach(var e in Network){
                if(!e.LimitEnabled)continue;
                if(e.TotalBytes>=e.LimitBytes){Log("NET-LIMIT",e.Pid.ToString(),e.Name,$"hit {Fmt(e.LimitBytes)} → blocking");AddToBlacklist(e.Name,BlacklistType.Process);e.LimitEnabled=false;}
            }
            if(_netLimEn){foreach(var e in Network){if(e.TotalBytes>=(long)(_netLimMb*1_048_576)){Log("GLOBAL-LIMIT",e.Pid.ToString(),e.Name,"global limit → blocking");AddToBlacklist(e.Name,BlacklistType.Process);}}}
        }

        void CheckVpn(){var s=_vpn.Check();VpnActive=s.IsActive;VpnLabel=s.IsActive?$"VPN ACTIVE — {s.Name}":"NO VPN DETECTED";}

        public void KillProcess(int pid,bool blacklist,Point pt){
            AnimeState=blacklist?AnimeState.Blocking:AnimeState.Killing;
            KillAnimationRequested?.Invoke(pt);
            SoundManager.Play(blacklist?SoundHint.Block:SoundHint.Kill);
            var(name,result)=_proc.Kill(pid);Log("KILL",pid.ToString(),name,result);
            if(blacklist&&!string.IsNullOrEmpty(name))AddToBlacklist(name,BlacklistType.Process);
            var e=Processes.FirstOrDefault(p=>p.Pid==pid);if(e!=null)Processes.Remove(e);
            Task.Delay(2500).ContinueWith(_=>Application.Current?.Dispatcher.Invoke(()=>AnimeState=AnimeState.Normal));
        }

        public void StopAndBlacklistService(string name){
            AnimeState=AnimeState.Blocking;SoundManager.Play(SoundHint.Block);
            var e=Services.FirstOrDefault(s=>s.ServiceName==name);
            Task.Run(()=>{var r=_svc.StopOnly(name);Application.Current.Dispatcher.Invoke(()=>{if(e!=null)e.Status="Stopped";Log("SVC-BLOCK","—",name,r);AddToBlacklist(name,BlacklistType.Service);});});
            Task.Delay(2500).ContinueWith(_=>Application.Current?.Dispatcher.Invoke(()=>AnimeState=AnimeState.Normal));
        }

        public void ToggleService(string name){
            var e=Services.FirstOrDefault(s=>s.ServiceName==name);
            Task.Run(()=>{var(st,r)=_svc.Toggle(name);Application.Current.Dispatcher.Invoke(()=>{if(e!=null)e.Status=st;Log("SVC","—",name,r);});});
        }

        public void BlockNetworkProcess(string name){AnimeState=AnimeState.Blocking;SoundManager.Play(SoundHint.Block);AddToBlacklist(name,BlacklistType.Process);Task.Delay(2500).ContinueWith(_=>Application.Current?.Dispatcher.Invoke(()=>AnimeState=AnimeState.Normal));}
        public void ToggleStartup(StartupEntry e){_start.Toggle(e);Log("STARTUP","—",e.Name,e.IsEnabled?"enabled":"disabled");}
        public void AddToBlacklist(string name,BlacklistType type){_bl.Add(name,type);if(_tab==ActiveTab.Blacklist)RefreshBl();Log("BLACKLIST","—",name,$"added ({type})");}
        public void RemoveFromBlacklist(int id){var e=Blacklist.FirstOrDefault(x=>x.Id==id);_bl.Remove(id);if(e!=null)Blacklist.Remove(e);Log("BLACKLIST","—",e?.Name??"?","removed");StatusText=$"{Blacklist.Count} blacklisted";}
        public void SetBlacklistActive(int id,bool active){_bl.SetActive(id,active);var e=Blacklist.FirstOrDefault(x=>x.Id==id);if(e!=null)e.IsActive=active;Log("BLACKLIST","—",e?.Name??"?",active?"enforcement ON":"paused");}
        public void ClearLog(){KillLog.Clear();KillCount=0;}

        void Log(string type,string pid,string name,string result){
            KillLog.Insert(0,new KillLogEntry{Time=DateTime.Now.ToString("HH:mm:ss"),Tag=$"[{type}:{pid}]",Name=name,Result=result});
            KillCount=KillLog.Count;KillLogUpdated?.Invoke();
        }

        static string Fmt(long b){if(b==0)return"0 B/s";if(b<1024)return$"{b} B/s";if(b<1_048_576)return$"{b/1024.0:F1} KB/s";return$"{b/1_048_576.0:F1} MB/s";}
    }
}
