using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using WpfAnimatedGif;
using SupressIt.Helpers;
using SupressIt.Models;
using SupressIt.ViewModels;

namespace SupressIt
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel     _vm;
        private readonly SettingsViewModel _svm;
        private GifPlayer    _gifPlayer;
        private KillAnimator _killAnimator;

        // Track what the panel is currently showing so speed changes work realtime
        private AnimeState _panelState = AnimeState.Normal;

        public MainWindow()
        {
            var settings = SettingsStore.Load();
            ThemeManager.Apply(settings);

            InitializeComponent();

            _svm = new SettingsViewModel(settings);
            _svm.BackgroundChanged      += ApplyBackground;
            _svm.ThemeChanged           += () => { ApplyShellBg(); SyncDeathAnimToPanel(); };
            _svm.ElementsOpacityChanged += ApplyElementsOpacity;

            // FIX 5: Realtime GIF reload on path OR speed change
            _svm.GifSettingsChanged += OnGifSettingsChanged;
            _svm.GifSettingsChanged += what =>
            {
                if (what == "deathType" || what == "deathDuration")
                    SyncDeathAnimToPanel();
            };

            _vm = new MainViewModel();
            _vm.KillLogUpdated         += () => LogScroll.ScrollToTop();
            _vm.AnimeStateChanged      += OnAnimeStateChanged;
            _vm.KillAnimationRequested += OnKillAnimationRequested;

            DataContext               = _vm;
            PanelSettings.DataContext = _svm;

            // Wire panel action events
            PanelApps.KillRequested            += (pid, bl, pt, _) => _vm.KillProcess(pid, bl, pt);
            PanelSystem.ToggleRequested        += name  => _vm.ToggleService(name);
            PanelSystem.BlockRequested         += name  => _vm.StopAndBlacklistService(name);
            PanelInternet.BlockRequested       += name  => _vm.BlockNetworkProcess(name);
            PanelStartup.ToggleRequested       += entry => _vm.ToggleStartup(entry);
            PanelBlocked.ToggleActiveRequested += (id, active) => _vm.SetBlacklistActive(id, active);
            PanelBlocked.RemoveRequested       += id   => _vm.RemoveFromBlacklist(id);

            SoundManager.Init(settings);

            _gifPlayer    = new GifPlayer(GifContainer);
            _killAnimator = new KillAnimator(OverlayCanvas);

            Loaded += (_, _) =>
            {
                ApplyShellBg();
                ApplyBackground();
                PlayGifForState(AnimeState.Normal);
                SetLabel(AnimeState.Normal);
                SyncDeathAnimToPanel();
                ApplyElementsOpacity(_svm.ElementsOpacity);
            };
        }

        // ── Shell background ──────────────────────────────────────────────────

        private void ApplyShellBg()
        {
            if (TryFindResource("BgShell") is SolidColorBrush b)
                ShellBorder.Background = b;
        }

        // ── Elements opacity ──────────────────────────────────────────────────

        private void ApplyElementsOpacity(double opacity)
        {
            foreach (var el in new FrameworkElement[]
                { PanelApps, PanelSystem, PanelInternet, PanelStartup,
                  PanelBlocked, PanelSettings, AnimeSidePanel })
                el.Opacity = opacity;
        }

        // ── Death animation sync ──────────────────────────────────────────────

        private void SyncDeathAnimToPanel()
        {
            PanelApps.DeathAnimationType     = _svm.ItemDeathAnimation;
            PanelApps.DeathAnimationDuration = _svm.ItemDeathDuration;
        }

        // ── Custom background ─────────────────────────────────────────────────

        private void ApplyBackground()
        {
            BgImage.BeginAnimation(Image.SourceProperty, null);
            BgImage.Visibility = Visibility.Collapsed;
            BgVideo.Stop();
            BgVideo.Visibility = Visibility.Collapsed;

            if (!_svm.UseCustomBackground) return;
            string path = _svm.BackgroundPath;
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return;

            double op  = _svm.BackgroundOpacity;
            string ext = Path.GetExtension(path).ToLowerInvariant();

            if (ext is ".webm" or ".mp4")
            {
                BgVideo.Source     = new Uri(path, UriKind.Absolute);
                BgVideo.Opacity    = op;
                BgVideo.Visibility = Visibility.Visible;
                BgVideo.Play();
                BgVideo.MediaEnded += (_, _) => { BgVideo.Position = TimeSpan.Zero; BgVideo.Play(); };
            }
            else if (ext == ".gif")
            {
                try
                {
                    var src = new BitmapImage();
                    src.BeginInit();
                    src.UriSource   = new Uri(path, UriKind.Absolute);
                    src.CacheOption = BitmapCacheOption.OnLoad;
                    src.EndInit();
                    src.Freeze();
                    ImageBehavior.SetAnimatedSource(BgImage, src);
                    ImageBehavior.SetRepeatBehavior(BgImage, RepeatBehavior.Forever);
                    BgImage.Opacity    = op;
                    BgImage.Visibility = Visibility.Visible;
                }
                catch { }
            }
            else
            {
                try
                {
                    BgImage.Source     = new BitmapImage(new Uri(path, UriKind.Absolute));
                    BgImage.Opacity    = op;
                    BgImage.Visibility = Visibility.Visible;
                }
                catch { }
            }
        }

        // ── Anime GIF — FIX 2: panel only shows Normal/Searching ─────────────

        /// <summary>
        /// FIX 2: The panel ONLY switches between Normal and Searching.
        /// Kill/Block GIFs belong to the flying KillAnimator image only.
        /// This is the single source of truth for what the panel plays.
        /// </summary>
        private void PlayGifForState(AnimeState state)
        {
            if (!_svm.GifsEnabled) { _gifPlayer?.Stop(); return; }

            // Map Kill→Normal, Block→Normal for the panel
            AnimeState panelState = state switch
            {
                AnimeState.Searching => AnimeState.Searching,
                _                    => AnimeState.Normal
            };
            _panelState = panelState;

            (string path, double speed) = panelState == AnimeState.Searching
                ? (_svm.GifSearchingPath, _svm.GifSearchingSpeed)
                : (_svm.GifNormalPath,    _svm.GifNormalSpeed);

            _gifPlayer?.Play(path, speed);
        }

        // FIX 5: Realtime GIF settings changes
        private void OnGifSettingsChanged(string what)
        {
            if (!_svm.GifsEnabled) { _gifPlayer?.Stop(); return; }

            // Speed-only changes: update without full reload (no flicker)
            if (what == "normalSpeed" && _panelState == AnimeState.Normal)
            {
                _gifPlayer?.SetSpeed(_svm.GifNormalSpeed);
                return;
            }
            if (what == "searchingSpeed" && _panelState == AnimeState.Searching)
            {
                _gifPlayer?.SetSpeed(_svm.GifSearchingSpeed);
                return;
            }
            // Kill/block speed changes affect KillAnimator — update it next time it flies
            // (no action needed here since KillAnimator reads speed at Fly() call time)
            if (what is "killSpeed" or "blockSpeed" or "killType" or "deathType" or "deathDuration")
                return;

            // Path changed, master toggle, or "all" — reload panel GIF
            PlayGifForState(_vm.AnimeState);
        }

        private void OnAnimeStateChanged(AnimeState state)
        {
            SetLabel(state);
            PlayGifForState(state);  // panel stays Normal unless Searching
        }

        private void SetLabel(AnimeState state)
        {
            (AnimeLabel.Text, AnimeTip.Text) = state switch
            {
                AnimeState.Searching => ("( •̀ω•́ ) searching...", "Looking through the list!"),
                AnimeState.Killing   => ("( ≧▽≦ ) SMASH!!!",      "Byeeee! ✨💥"),
                AnimeState.Blocking  => ("( `д´) BLOCKED!",        "You shall not pass! 🚫"),
                _                    => ("( ˘ᵕ˙ ) chilling~",     "Click 🔨 to smash an app!")
            };
        }

        // ── Kill fly animation ────────────────────────────────────────────────

        private void OnKillAnimationRequested(Point targetScreen)
        {
            if (!_svm.GifsEnabled) return;

            var startScreen = GifContainer.PointToScreen(
                new Point(GifContainer.ActualWidth / 2, GifContainer.ActualHeight / 2));

            _killAnimator.Fly(
                _svm.GifKillPath,
                startScreen,
                targetScreen,
                _svm.KillAnimationSpeed,
                _svm.KillAnimationType);
        }

        // ── Tab switching ─────────────────────────────────────────────────────

        private void Tab_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not ToggleButton btn) return;

            foreach (var t in new[] { TabApps, TabSystem, TabInternet, TabStartup, TabBlocked, TabSettings })
                t.IsChecked = false;
            btn.IsChecked = true;

            PanelApps.Visibility     = Visibility.Collapsed;
            PanelSystem.Visibility   = Visibility.Collapsed;
            PanelInternet.Visibility = Visibility.Collapsed;
            PanelStartup.Visibility  = Visibility.Collapsed;
            PanelBlocked.Visibility  = Visibility.Collapsed;
            PanelSettings.Visibility = Visibility.Collapsed;

            switch (btn.Tag?.ToString())
            {
                case "Apps":     PanelApps.Visibility     = Visibility.Visible; _vm.ActiveTab = ActiveTab.Processes; break;
                case "System":   PanelSystem.Visibility   = Visibility.Visible; _vm.ActiveTab = ActiveTab.Services;  break;
                case "Internet": PanelInternet.Visibility = Visibility.Visible; _vm.ActiveTab = ActiveTab.Network;   break;
                case "Startup":  PanelStartup.Visibility  = Visibility.Visible; _vm.ActiveTab = ActiveTab.Startup;   break;
                case "Blocked":  PanelBlocked.Visibility  = Visibility.Visible; _vm.ActiveTab = ActiveTab.Blacklist; break;
                case "Settings": PanelSettings.Visibility = Visibility.Visible; _vm.ActiveTab = ActiveTab.Settings;  break;
            }
        }

        private void ClearLog_Click(object sender, RoutedEventArgs e) => _vm.ClearLog();

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }

        private void Minimize_Click(object sender, RoutedEventArgs e) =>
            WindowState = WindowState.Minimized;

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            _vm.Shutdown();
            _svm.Save();
            Close();
        }
    }
}
