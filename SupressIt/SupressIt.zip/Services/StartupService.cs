using System; using System.Collections.Generic; using System.IO; using System.Linq;
using Microsoft.Win32; using SupressIt.Models;
namespace SupressIt.Services
{
    public class StartupService
    {
        const string RHkcu=@"Software\Microsoft\Windows\CurrentVersion\Run";
        const string RHklm=@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
        const string AHkcu=@"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run";
        const string AHklm=@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run";

        public List<StartupEntry> GetStartupEntries(string filter=""){
            var list=new List<StartupEntry>(); var low=filter?.ToLower()??"";
            var dCu=Disabled(Registry.CurrentUser,AHkcu); var dLm=Disabled(Registry.LocalMachine,AHklm);
            ReadKey(Registry.CurrentUser,RHkcu,"HKCU Run",dCu,list);
            ReadKey(Registry.LocalMachine,RHklm,"HKLM Run",dLm,list);
            ReadFolder(Environment.GetFolderPath(Environment.SpecialFolder.Startup),"User Startup",list);
            ReadFolder(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup),"Common Startup",list);
            if(!string.IsNullOrEmpty(low))list=list.Where(e=>e.Name.ToLower().Contains(low)).ToList();
            return list.OrderBy(e=>e.Name).ToList();
        }

        public bool Toggle(StartupEntry e){
            try{bool lm=e.Location.StartsWith("HKLM");
                var root=lm?Registry.LocalMachine:Registry.CurrentUser;
                var ak=lm?AHklm:AHkcu;
                using var k=root.OpenSubKey(ak,true)??root.CreateSubKey(ak);
                var d=new byte[12]; d[0]=e.IsEnabled?(byte)0x03:(byte)0x02;
                k.SetValue(e.Name,d,RegistryValueKind.Binary); e.IsEnabled=!e.IsEnabled;}catch{}
            return e.IsEnabled;
        }

        static HashSet<string> Disabled(RegistryKey root,string sub){
            var s=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try{using var k=root.OpenSubKey(sub);if(k==null)return s;
                foreach(var n in k.GetValueNames()){var r=k.GetValue(n) as byte[];if(r?.Length>=1&&r[0]==0x03)s.Add(n);}}catch{}
            return s;
        }
        static void ReadKey(RegistryKey root,string sub,string loc,HashSet<string> dis,List<StartupEntry> target){
            try{using var k=root.OpenSubKey(sub);if(k==null)return;
                foreach(var n in k.GetValueNames()){string cmd=k.GetValue(n)?.ToString()??"";
                    target.Add(new StartupEntry{Name=n,Command=cmd,Location=loc,IsEnabled=!dis.Contains(n)});}}catch{}
        }
        static void ReadFolder(string folder,string loc,List<StartupEntry> target){
            try{if(!Directory.Exists(folder))return;
                foreach(var f in Directory.GetFiles(folder,"*.lnk"))
                    target.Add(new StartupEntry{Name=Path.GetFileNameWithoutExtension(f),Command=f,Location=loc,IsEnabled=true});}catch{}
        }
    }
}
