using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;

namespace SupressIt.Helpers
{
    /// <summary>
    /// Plays a death animation on a FrameworkElement (a card row),
    /// then calls onComplete so the VM can remove it from the collection.
    /// Animation types: Burn | Fade | Shrink | None
    /// </summary>
    public static class DeathAnimator
    {
        public static void Play(FrameworkElement element, string type, double durationSec,
            Action onComplete)
        {
            if (element == null || type == "None") { onComplete?.Invoke(); return; }

            double ms = Math.Max(100, durationSec * 1000);

            switch (type)
            {
                case "Burn":   PlayBurn(element, ms, onComplete);   break;
                case "Shrink": PlayShrink(element, ms, onComplete); break;
                default:       PlayFade(element, ms, onComplete);   break;
            }
        }

        // ── Burn ─────────────────────────────────────────────────────────────

        private static void PlayBurn(FrameworkElement el, double ms, Action done)
        {
            // Phase 1: flash red/orange (BlurEffect + color shift)
            // Phase 2: scale up slightly + fade out (like burning away)
            var tg = EnsureTransform(el);
            var scale = (ScaleTransform)tg.Children[0];

            // Red flash via opacity + render trick
            var redFlash = new ColorAnimation(
                Color.FromArgb(0, 255, 100, 0),
                Color.FromArgb(180, 255, 80, 0),
                TimeSpan.FromMilliseconds(ms * 0.3))
            { AutoReverse = true };

            // Scale up slightly then shrink to nothing
            var scaleUp = new DoubleAnimation(1.0, 1.06, TimeSpan.FromMilliseconds(ms * 0.25));
            var scaleFade = new DoubleAnimation(1.06, 0.0, TimeSpan.FromMilliseconds(ms * 0.65))
            {
                BeginTime      = TimeSpan.FromMilliseconds(ms * 0.25),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };

            // Opacity burn-out
            var fadeOut = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(ms * 0.7))
            {
                BeginTime = TimeSpan.FromMilliseconds(ms * 0.3)
            };
            fadeOut.Completed += (_, _) =>
            {
                el.Opacity = 0;
                done?.Invoke();
            };

            // Apply blur at peak
            var blur = new BlurEffect { Radius = 0 };
            el.Effect = blur;
            var blurAnim = new DoubleAnimation(0, 8, TimeSpan.FromMilliseconds(ms * 0.5))
            {
                BeginTime = TimeSpan.FromMilliseconds(ms * 0.3)
            };
            blur.BeginAnimation(BlurEffect.RadiusProperty, blurAnim);

            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleUp);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleUp);
            var sb2 = new Storyboard();
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleFade);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleFade);
            el.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }

        // ── Fade ─────────────────────────────────────────────────────────────

        private static void PlayFade(FrameworkElement el, double ms, Action done)
        {
            var anim = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(ms))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };
            anim.Completed += (_, _) => { el.Opacity = 0; done?.Invoke(); };
            el.BeginAnimation(UIElement.OpacityProperty, anim);
        }

        // ── Shrink ────────────────────────────────────────────────────────────

        private static void PlayShrink(FrameworkElement el, double ms, Action done)
        {
            var tg    = EnsureTransform(el);
            var scale = (ScaleTransform)tg.Children[0];

            var sx = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(ms))
            {
                EasingFunction = new BackEase { EasingMode = EasingMode.EaseIn, Amplitude = 0.3 }
            };
            var fade = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(ms * 0.6))
            {
                BeginTime = TimeSpan.FromMilliseconds(ms * 0.4)
            };
            fade.Completed += (_, _) => { el.Opacity = 0; done?.Invoke(); };

            scale.BeginAnimation(ScaleTransform.ScaleXProperty, sx);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, sx);
            el.BeginAnimation(UIElement.OpacityProperty, fade);
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        private static TransformGroup EnsureTransform(FrameworkElement el)
        {
            if (el.RenderTransform is TransformGroup tg &&
                tg.Children.Count >= 1 &&
                tg.Children[0] is ScaleTransform)
                return tg;

            var newTg = new TransformGroup();
            newTg.Children.Add(new ScaleTransform(1, 1) );
            newTg.Children.Add(new TranslateTransform(0, 0));
            el.RenderTransformOrigin = new Point(0.5, 0.5);
            el.RenderTransform = newTg;
            return newTg;
        }
    }
}
