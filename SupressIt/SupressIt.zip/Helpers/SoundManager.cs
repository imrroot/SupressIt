using System;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using SupressIt.Models;

namespace SupressIt.Helpers
{
    public enum SoundHint { Normal, Searching, Kill, Block }

    /// <summary>
    /// Plays sounds using MediaElement (which supports MP3 natively via WMP codecs).
    /// MediaElement must live on a UI thread inside the visual tree, so we host it
    /// in an invisible Window.
    /// </summary>
    public static class SoundManager
    {
        private static AppSettings  _s;
        private static SoundHost    _host;
        private static bool         _initialized;

        public static void Init(AppSettings s)
        {
            _s = s;
            EnsureHost();
        }

        public static void Play(SoundHint hint)
        {
            if (_s == null || !_s.SoundEnabled)
            {
                if (hint == SoundHint.Kill || hint == SoundHint.Block)
                    KillSound.Play();
                return;
            }

            string path = hint switch
            {
                SoundHint.Kill      => _s.SoundKillPath,
                SoundHint.Block     => _s.SoundBlockPath,
                SoundHint.Searching => _s.SoundSearchingPath,
                _                   => _s.SoundNormalPath
            };

            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                EnsureHost();
                Application.Current?.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        _host?.PlayFile(path,
                            Math.Clamp(_s?.SoundVolume ?? 0.8, 0, 1),
                            Math.Max(0.1, _s?.SoundSpeed ?? 1.0));
                    }
                    catch { }
                });
            }
            else if (hint == SoundHint.Kill || hint == SoundHint.Block)
            {
                KillSound.Play();
            }
        }

        private static void EnsureHost()
        {
            if (_initialized) return;
            _initialized = true;
            Application.Current?.Dispatcher.Invoke(() =>
            {
                _host = new SoundHost();
            });
        }
    }

    // Invisible helper window that hosts MediaElement (required for MP3 decoding)
    internal class SoundHost
    {
        private readonly System.Windows.Controls.MediaElement _me;

        public SoundHost()
        {
            _me = new System.Windows.Controls.MediaElement
            {
                LoadedBehavior   = System.Windows.Controls.MediaState.Manual,
                UnloadedBehavior = System.Windows.Controls.MediaState.Stop,
                Visibility       = Visibility.Collapsed,
                Volume           = 0.8
            };

            // Add to a hidden panel so MediaElement is in visual tree
            var win = Application.Current.MainWindow;
            if (win?.Content is System.Windows.Controls.Panel panel)
                panel.Children.Add(_me);
            else
            {
                // Fallback: add to an invisible window
                var host = new Window
                {
                    Width = 1, Height = 1, Opacity = 0,
                    ShowInTaskbar = false, WindowStyle = WindowStyle.None,
                    ResizeMode = ResizeMode.NoResize,
                    AllowsTransparency = true
                };
                var grid = new System.Windows.Controls.Grid();
                grid.Children.Add(_me);
                host.Content = grid;
                host.Show();
            }

            _me.MediaEnded += (_, _) => _me.Stop();
        }

        public void PlayFile(string path, double volume, double speed)
        {
            _me.Stop();
            _me.Source      = new Uri(path, UriKind.Absolute);
            _me.Volume      = volume;
            _me.SpeedRatio  = speed;
            _me.Play();
        }
    }
}
