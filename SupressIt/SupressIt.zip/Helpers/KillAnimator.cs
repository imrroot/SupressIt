using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using WpfAnimatedGif;

namespace SupressIt.Helpers
{
    /// <summary>
    /// Manages the kill-GIF fly animation.
    /// The flying image lives on an overlay Canvas (Panel.ZIndex=999)
    /// so it truly flies over the process list rows.
    /// </summary>
    public class KillAnimator
    {
        private readonly Canvas _overlay;
        private Image           _flyer;
        private string          _loadedPath;

        public event Action ItemDied;

        public KillAnimator(Canvas overlay) => _overlay = overlay;

        public void Fly(
            string gifPath,
            Point  startScreen,   // centre of anime panel GIF box (screen coords)
            Point  targetScreen,  // centre of the kill button that was clicked (screen coords)
            double speedMult,
            string animType)
        {
            if (string.IsNullOrEmpty(gifPath) || !File.Exists(gifPath))
            {
                ItemDied?.Invoke();
                return;
            }

            // Build flyer if needed
            if (!EnsureFlyer(gifPath, speedMult))
            {
                ItemDied?.Invoke();
                return;
            }

            // FIX 3: Convert screen → overlay canvas local coords
            // OverlayCanvas fills the whole window so PointFromScreen gives correct position
            Point sc, tc;
            try
            {
                sc = _overlay.PointFromScreen(startScreen);
                tc = _overlay.PointFromScreen(targetScreen);
            }
            catch
            {
                ItemDied?.Invoke();
                return;
            }

            // Place flyer centred on start point
            double hw = _flyer.Width  / 2;
            double hh = _flyer.Height / 2;

            Canvas.SetLeft(_flyer, sc.X - hw);
            Canvas.SetTop( _flyer, sc.Y - hh);
            _flyer.Visibility = Visibility.Visible;
            _flyer.Opacity    = 1;

            double flyMs = 420 / Math.Max(0.1, speedMult);
            double retMs = 320 / Math.Max(0.1, speedMult);

            var tg  = (TransformGroup)_flyer.RenderTransform;
            var rot = (RotateTransform)tg.Children[1];
            var scl = (ScaleTransform) tg.Children[0];

            // Reset transforms
            rot.Angle  = 0;
            scl.ScaleX = 1;
            scl.ScaleY = 1;

            // ── Fly-out animations ────────────────────────────────────────────
            double spinTo = animType switch
            {
                "Spin"   => 720,
                "Bounce" => 180,
                _        => 360   // Fly
            };

            IEasingFunction flyEase = animType == "Bounce"
                ? (IEasingFunction)new ElasticEase { Oscillations = 1, Springiness = 5, EasingMode = EasingMode.EaseOut }
                : new CubicEase { EasingMode = EasingMode.EaseIn };

            var ax   = Anim(sc.X - hw, tc.X - hw, flyMs, flyEase);
            var ay   = Anim(sc.Y - hh, tc.Y - hh, flyMs, flyEase);
            var spin = Anim(0, spinTo, flyMs, new CubicEase { EasingMode = EasingMode.EaseIn });

            // Scale up slightly as it approaches target (looks like it's hitting)
            var scaleUp = Anim(1.0, 1.4, flyMs * 0.7,
                new CubicEase { EasingMode = EasingMode.EaseIn });

            ax.Completed += (_, _) =>
            {
                ItemDied?.Invoke();

                // ── Fly-back animations ───────────────────────────────────────
                var retDelay = TimeSpan.FromMilliseconds(80);

                var rx = new DoubleAnimation(tc.X - hw, sc.X - hw, TimeSpan.FromMilliseconds(retMs))
                {
                    BeginTime = retDelay,
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };
                var ry = new DoubleAnimation(tc.Y - hh, sc.Y - hh, TimeSpan.FromMilliseconds(retMs))
                {
                    BeginTime = retDelay,
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };
                var spinBack = new DoubleAnimation(rot.Angle, 0, TimeSpan.FromMilliseconds(retMs))
                {
                    BeginTime = retDelay,
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };
                var scaleBack = new DoubleAnimation(scl.ScaleX, 1.0, TimeSpan.FromMilliseconds(retMs))
                {
                    BeginTime = retDelay
                };
                var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(retMs * 0.4))
                {
                    BeginTime = TimeSpan.FromMilliseconds(retDelay.TotalMilliseconds + retMs * 0.6)
                };

                fadeOut.Completed += (_, _) => _flyer.Visibility = Visibility.Collapsed;

                _flyer.BeginAnimation(Canvas.LeftProperty,  rx);
                _flyer.BeginAnimation(Canvas.TopProperty,   ry);
                _flyer.BeginAnimation(UIElement.OpacityProperty, fadeOut);
                rot.BeginAnimation(RotateTransform.AngleProperty, spinBack);
                scl.BeginAnimation(ScaleTransform.ScaleXProperty, scaleBack);
                scl.BeginAnimation(ScaleTransform.ScaleYProperty, scaleBack);
            };

            _flyer.BeginAnimation(Canvas.LeftProperty, ax);
            _flyer.BeginAnimation(Canvas.TopProperty,  ay);
            rot.BeginAnimation(RotateTransform.AngleProperty, spin);
            scl.BeginAnimation(ScaleTransform.ScaleXProperty, scaleUp);
            scl.BeginAnimation(ScaleTransform.ScaleYProperty, scaleUp);
        }

        // ── Private ───────────────────────────────────────────────────────────

        private bool EnsureFlyer(string gifPath, double speedMult)
        {
            if (_flyer != null && gifPath == _loadedPath)
            {
                ImageBehavior.SetAnimationSpeedRatio(_flyer, Math.Max(0.1, speedMult));
                return true;
            }

            // Remove old flyer
            if (_flyer != null)
            {
                ImageBehavior.SetAnimatedSource(_flyer, null);
                _overlay.Children.Remove(_flyer);
                _flyer = null;
            }

            _loadedPath = gifPath;

            _flyer = new Image
            {
                Width                 = 130,
                Height                = 130,
                IsHitTestVisible      = false,
                Visibility            = Visibility.Collapsed,
                RenderTransformOrigin = new Point(0.5, 0.5),
                RenderTransform       = new TransformGroup
                {
                    Children =
                    {
                        new ScaleTransform(1, 1),
                        new RotateTransform(0)
                    }
                }
            };
            RenderOptions.SetBitmapScalingMode(_flyer, BitmapScalingMode.HighQuality);

            try
            {
                var src = new BitmapImage();
                src.BeginInit();
                src.UriSource   = new Uri(gifPath, UriKind.Absolute);
                src.CacheOption = BitmapCacheOption.OnLoad;
                src.EndInit();
                src.Freeze();

                ImageBehavior.SetAnimatedSource(_flyer, src);
                ImageBehavior.SetRepeatBehavior(_flyer, RepeatBehavior.Forever);
                ImageBehavior.SetAnimationSpeedRatio(_flyer, Math.Max(0.1, speedMult));
            }
            catch
            {
                _flyer = null;
                _loadedPath = null;
                return false;
            }

            _overlay.Children.Add(_flyer);
            return true;
        }

        private static DoubleAnimation Anim(double from, double to, double ms,
            IEasingFunction ease, double delayMs = 0) => new()
        {
            From           = from,
            To             = to,
            Duration       = TimeSpan.FromMilliseconds(ms),
            BeginTime      = delayMs > 0 ? TimeSpan.FromMilliseconds(delayMs) : (TimeSpan?)null,
            EasingFunction = ease
        };
    }
}
