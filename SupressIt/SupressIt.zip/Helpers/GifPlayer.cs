using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using WpfAnimatedGif;

namespace SupressIt.Helpers
{
    /// <summary>
    /// Plays one GIF/WebM at a time inside a Grid host.
    /// Panel state: Normal and Searching only.
    /// Kill/Block GIFs are shown by KillAnimator on the overlay Canvas — never here.
    /// </summary>
    public class GifPlayer
    {
        private readonly Grid  _host;
        private Image          _gifImg;
        private MediaElement   _vidEl;
        private string         _curPath;
        private double         _curSpeed = -1;

        public GifPlayer(Grid host) => _host = host;

        /// <summary>force=true re-loads even if path+speed unchanged (for speed slider realtime)</summary>
        public void Play(string path, double speed = 1.0, bool force = false)
        {
            if (!force && path == _curPath && Math.Abs(speed - _curSpeed) < 0.001)
                return;

            StopAll();
            _curPath  = path;
            _curSpeed = speed;

            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return;

            string ext = Path.GetExtension(path).ToLowerInvariant();
            if (ext is ".webm" or ".mp4" or ".avi")
                PlayVideo(path, speed);
            else
                PlayGif(path, speed);
        }

        /// <summary>Change speed on the already-playing GIF without reloading.</summary>
        public void SetSpeed(double speed)
        {
            _curSpeed = speed;
            if (_gifImg != null)
                ImageBehavior.SetAnimationSpeedRatio(_gifImg, Math.Max(0.1, speed));
            if (_vidEl != null)
                _vidEl.SpeedRatio = Math.Max(0.1, speed);
        }

        public void Stop()
        {
            StopAll();
            _curPath  = null;
            _curSpeed = -1;
        }

        // ── GIF via WpfAnimatedGif ────────────────────────────────────────────

        private void PlayGif(string path, double speed)
        {
            try
            {
                _gifImg = new Image
                {
                    Stretch             = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center
                };
                RenderOptions.SetBitmapScalingMode(_gifImg, BitmapScalingMode.HighQuality);

                var src = new BitmapImage();
                src.BeginInit();
                src.UriSource   = new Uri(path, UriKind.Absolute);
                src.CacheOption = BitmapCacheOption.OnLoad;
                src.EndInit();
                src.Freeze();

                ImageBehavior.SetAnimatedSource(_gifImg, src);
                //ImageBehavior.SetRepeatBehavior(_gifImg, RepeatBehavior.Forever);
                ImageBehavior.SetAnimationSpeedRatio(_gifImg, Math.Max(0.1, speed));

                _host.Children.Add(_gifImg);
            }
            catch { }
        }

        // ── WebM/MP4 via MediaElement ─────────────────────────────────────────
        // FIX 3: MediaElement needs a proper size in its parent.
        // We give it explicit Width/Height matching the host at creation time.

        private void PlayVideo(string path, double speed)
        {
            try
            {
                _vidEl = new MediaElement
                {
                    Source              = new Uri(path, UriKind.Absolute),
                    LoadedBehavior      = MediaState.Manual,
                    UnloadedBehavior    = MediaState.Stop,
                    Stretch             = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    VerticalAlignment   = VerticalAlignment.Stretch,
                    SpeedRatio          = Math.Max(0.1, speed)
                };
                _vidEl.MediaOpened += (_, _) => _vidEl.Play();
                _vidEl.MediaEnded  += (_, _) =>
                {
                    _vidEl.Position = TimeSpan.Zero;
                    _vidEl.Play();
                };
                _host.Children.Add(_vidEl);
                // Explicit Play() in case MediaOpened already fired before we subscribed
                _vidEl.Play();
            }
            catch { }
        }

        // ── Cleanup ───────────────────────────────────────────────────────────

        private void StopAll()
        {
            if (_gifImg != null)
            {
                ImageBehavior.SetAnimatedSource(_gifImg, null);
                _host.Children.Remove(_gifImg);
                _gifImg = null;
            }
            if (_vidEl != null)
            {
                _vidEl.Stop();
                _vidEl.Source = null;
                _host.Children.Remove(_vidEl);
                _vidEl = null;
            }
        }
    }
}
